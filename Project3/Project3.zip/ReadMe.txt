There's syntax like this in my code:
	int n=10;
	int arr[n];
It is acceptable for not all compilers to represent the size by a variable when defining an array. It could also lead to an error during compiling. So if you failed in compiling, please change a new compiler and try again. It's not a mistake.

To be brief, the purpose and expected output of each test case are written in Chap.3 in my report. There's only figures in TestCase.txt.